import { User, UserRole, Restaurant, MenuItem, Order } from '../types';

// Initial Data
const INITIAL_USERS: User[] = [
  { id: 'u1', name: 'Big Boss', email: 'owner@app.com', password: '123', role: UserRole.OWNER },
  { id: 'u2', name: 'Manager Mike', email: 'admin@app.com', password: '123', role: UserRole.ADMIN },
  { id: 'u3', name: 'Hungry Joe', email: 'user@app.com', password: '123', role: UserRole.USER },
];

const INITIAL_RESTAURANTS: Restaurant[] = [
  { id: 'r1', name: 'Burger Kingz', image: 'https://picsum.photos/400/300?random=1', deliveryFee: 5.00, rating: 4.5, adminIds: ['u2'] },
  { id: 'r2', name: 'Pizza Palace', image: 'https://picsum.photos/400/300?random=2', deliveryFee: 3.50, rating: 4.2, adminIds: ['u2'] },
  { id: 'r3', name: 'Sushi Sensation', image: 'https://picsum.photos/400/300?random=3', deliveryFee: 6.00, rating: 4.8, adminIds: [] },
];

const INITIAL_MENU: MenuItem[] = [
  { id: 'm1', restaurantId: 'r1', name: 'Double Cheese Burger', description: 'Two beef patties with melted cheddar.', image: 'https://picsum.photos/200/200?random=10', basePrice: 12, category: 'Burgers' },
  { id: 'm2', restaurantId: 'r1', name: 'Crispy Fries', description: 'Golden salted fries.', image: 'https://picsum.photos/200/200?random=11', basePrice: 4, category: 'Sides' },
  { id: 'm3', restaurantId: 'r2', name: 'Pepperoni Feast', description: 'Loaded with spicy pepperoni.', image: 'https://picsum.photos/200/200?random=12', basePrice: 15, category: 'Pizza' },
  { id: 'm4', restaurantId: 'r3', name: 'Dragon Roll', description: 'Eel and avocado roll.', image: 'https://picsum.photos/200/200?random=13', basePrice: 18, category: 'Sushi' },
];

// Helper to load/save
const load = <T,>(key: string, initial: T): T => {
  const stored = localStorage.getItem(key);
  if (!stored) return initial;
  return JSON.parse(stored);
};

const save = (key: string, data: any) => {
  localStorage.setItem(key, JSON.stringify(data));
};

export const db = {
  getUsers: () => load<User[]>('users', INITIAL_USERS),
  saveUsers: (users: User[]) => save('users', users),
  
  getRestaurants: () => load<Restaurant[]>('restaurants', INITIAL_RESTAURANTS),
  saveRestaurants: (rests: Restaurant[]) => save('restaurants', rests),

  getMenu: () => load<MenuItem[]>('menu', INITIAL_MENU),
  saveMenu: (items: MenuItem[]) => save('menu', items),

  getOrders: () => load<Order[]>('orders', []),
  saveOrders: (orders: Order[]) => save('orders', orders),
};