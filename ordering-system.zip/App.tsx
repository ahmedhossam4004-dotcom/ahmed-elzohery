import React, { useState, useEffect } from 'react';
import { Layout } from './components/ui/Layout';
import { Auth } from './components/Auth';
import { UserDashboard } from './components/Dashboards/UserDashboard';
import { AdminDashboard } from './components/Dashboards/AdminDashboard';
import { OwnerDashboard } from './components/Dashboards/OwnerDashboard';
import { User, UserRole } from './types';
import { db } from './services/mockDb';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate checking session
    const storedUserId = localStorage.getItem('currentUserId');
    if (storedUserId) {
      const users = db.getUsers();
      const found = users.find(u => u.id === storedUserId);
      if (found) setUser(found);
    }
    setLoading(false);
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    localStorage.setItem('currentUserId', loggedInUser.id);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('currentUserId');
  };

  if (loading) return <div className="min-h-screen bg-background flex items-center justify-center text-primary">Loading System...</div>;

  return (
    <Layout user={user} onLogout={handleLogout}>
      {!user ? (
        <Auth onLogin={handleLogin} />
      ) : (
        <div className="animate-in fade-in duration-500">
          {user.role === UserRole.OWNER && (
            <div className="space-y-12">
               <OwnerDashboard />
               <div className="border-t border-border pt-8">
                 <h2 className="text-xl font-bold mb-4 opacity-50">Admin View Preview</h2>
                 <AdminDashboard currentUser={user} />
               </div>
            </div>
          )}

          {user.role === UserRole.ADMIN && (
             <AdminDashboard currentUser={user} />
          )}

          {user.role === UserRole.USER && (
            <UserDashboard currentUser={user} />
          )}
        </div>
      )}
    </Layout>
  );
};

export default App;