export enum UserRole {
  OWNER = 'OWNER',
  ADMIN = 'ADMIN',
  USER = 'USER',
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; // In a real app, never store plain text
  role: UserRole;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  image: string;
  basePrice: number;
  category: string;
}

export type Size = 'S' | 'M' | 'L';

export interface CartItem {
  itemId: string;
  name: string;
  size: Size;
  price: number;
  quantity: number;
  note?: string;
  restaurantId: string;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  items: CartItem[];
  total: number;
  status: 'PENDING' | 'PREPARING' | 'DELIVERED' | 'CANCELLED';
  createdAt: string; // ISO date
  deliveryFee: number;
}

export interface Restaurant {
  id: string;
  name: string;
  image: string;
  deliveryFee: number;
  rating: number;
  adminIds: string[]; // Admins responsible for this restaurant
}