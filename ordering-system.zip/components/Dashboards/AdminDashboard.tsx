import React, { useState, useEffect } from 'react';
import { User, Order, MenuItem, Restaurant } from '../../types';
import { db } from '../../services/mockDb';
import { Modal } from '../Popups';
import { Plus, Edit2, Trash2, Filter } from 'lucide-react';

export const AdminDashboard: React.FC<{ currentUser: User }> = ({ currentUser }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [myRestaurants, setMyRestaurants] = useState<Restaurant[]>([]);
  const [view, setView] = useState<'orders' | 'menu'>('orders');
  
  // Menu Editing State
  const [editingItem, setEditingItem] = useState<Partial<MenuItem> | null>(null);

  useEffect(() => {
    // 1. Get all restaurants
    const allRestaurants = db.getRestaurants();
    // 2. Filter for restaurants managed by this admin
    const managedRestaurants = allRestaurants.filter(r => r.adminIds.includes(currentUser.id));
    setMyRestaurants(managedRestaurants);
    const managedIds = managedRestaurants.map(r => r.id);

    // 3. Get relevant orders (Orders where items belong to managed restaurants)
    // Note: Assuming orders are single-restaurant based.
    const allOrders = db.getOrders();
    const relevantOrders = allOrders.filter(o => 
      o.items.length > 0 && managedIds.includes(o.items[0].restaurantId)
    );
    setOrders(relevantOrders);

    // 4. Get relevant menu items
    const allMenu = db.getMenu();
    const relevantMenu = allMenu.filter(m => managedIds.includes(m.restaurantId));
    setMenuItems(relevantMenu);
  }, [currentUser.id]);

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    // We need to update the global DB order list
    const allOrders = db.getOrders();
    const updatedGlobalOrders = allOrders.map(o => o.id === orderId ? { ...o, status } : o);
    db.saveOrders(updatedGlobalOrders);
    
    // Update local state
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };

  const handleSaveItem = () => {
    if (!editingItem?.name || !editingItem.basePrice || !editingItem.restaurantId) return;
    
    const allMenu = db.getMenu();
    let newGlobalMenu = [...allMenu];

    if (editingItem.id) {
      newGlobalMenu = newGlobalMenu.map(m => m.id === editingItem.id ? { ...m, ...editingItem } as MenuItem : m);
    } else {
      const newItem: MenuItem = {
        ...editingItem,
        id: `m-${Date.now()}`,
        image: editingItem.image || 'https://picsum.photos/200/200?food'
      } as MenuItem;
      newGlobalMenu.push(newItem);
    }
    
    db.saveMenu(newGlobalMenu);
    
    // Refresh local
    const managedIds = myRestaurants.map(r => r.id);
    setMenuItems(newGlobalMenu.filter(m => managedIds.includes(m.restaurantId)));
    setEditingItem(null);
  };

  const handleDeleteItem = (id: string) => {
    if (window.confirm('Delete this item?')) {
      const allMenu = db.getMenu();
      const newGlobalMenu = allMenu.filter(m => m.id !== id);
      db.saveMenu(newGlobalMenu);
      
      const managedIds = myRestaurants.map(r => r.id);
      setMenuItems(newGlobalMenu.filter(m => managedIds.includes(m.restaurantId)));
    }
  };

  const calculateTotalRevenue = () => {
    return orders
      .filter(o => o.status !== 'CANCELLED')
      .reduce((acc, curr) => acc + curr.total, 0);
  };

  if (myRestaurants.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-surface rounded-xl border border-border">
        <Filter size={48} className="text-textMuted mb-4" />
        <h2 className="text-xl font-bold">No Restaurants Assigned</h2>
        <p className="text-textMuted mt-2">Please ask the Owner to assign you to a restaurant.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <div className="bg-surface p-1 rounded-lg border border-border flex gap-1">
          <button 
            onClick={() => setView('orders')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${view === 'orders' ? 'bg-zinc-700 text-white' : 'text-textMuted hover:text-white'}`}
          >
            My Orders
          </button>
          <button 
            onClick={() => setView('menu')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${view === 'menu' ? 'bg-zinc-700 text-white' : 'text-textMuted hover:text-white'}`}
          >
            Menu Management
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-surface p-4 rounded-xl border border-border">
          <p className="text-textMuted text-sm">Total Revenue</p>
          <p className="text-2xl font-bold text-green-500">${calculateTotalRevenue().toFixed(2)}</p>
        </div>
        <div className="bg-surface p-4 rounded-xl border border-border">
          <p className="text-textMuted text-sm">Pending Orders</p>
          <p className="text-2xl font-bold text-yellow-500">{orders.filter(o => o.status === 'PENDING').length}</p>
        </div>
        <div className="bg-surface p-4 rounded-xl border border-border">
          <p className="text-textMuted text-sm">Total Orders</p>
          <p className="text-2xl font-bold">{orders.length}</p>
        </div>
      </div>

      {view === 'orders' ? (
        <div className="grid gap-4">
          {orders.length === 0 && <p className="text-textMuted text-center py-8">No orders for your restaurants yet.</p>}
          {[...orders].reverse().map(order => (
            <div key={order.id} className="bg-surface border border-border rounded-xl p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-lg">Order #{order.id.slice(-6)}</h3>
                  <p className="text-sm text-textMuted">Customer: {order.userName}</p>
                  <p className="text-xs text-textMuted">{new Date(order.createdAt).toLocaleString()}</p>
                  <span className="text-xs bg-zinc-800 px-2 py-0.5 rounded mt-1 inline-block">
                    {myRestaurants.find(r => r.id === order.items[0].restaurantId)?.name}
                  </span>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className="font-bold text-xl">${order.total.toFixed(2)}</span>
                  <select
                    value={order.status}
                    onChange={(e) => updateOrderStatus(order.id, e.target.value as Order['status'])}
                    className="bg-background border border-border rounded px-2 py-1 text-sm focus:border-primary outline-none"
                  >
                    <option value="PENDING">Pending</option>
                    <option value="PREPARING">Preparing</option>
                    <option value="DELIVERED">Delivered</option>
                    <option value="CANCELLED">Cancelled</option>
                  </select>
                </div>
              </div>
              
              <div className="space-y-2 bg-background p-4 rounded-lg">
                {order.items.map((item, i) => (
                  <div key={i} className="flex justify-between text-sm">
                    <span>{item.quantity}x {item.name} ({item.size})</span>
                    <span className="text-textMuted">{(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                {order.items.some(i => i.note) && (
                   <div className="pt-2 border-t border-border mt-2">
                     <p className="text-xs font-bold text-yellow-500">Notes:</p>
                     {order.items.map((item, i) => item.note ? <p key={i} className="text-xs text-textMuted">- {item.name}: {item.note}</p> : null)}
                   </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div>
          <div className="flex justify-end mb-4">
            <button 
              onClick={() => setEditingItem({ category: 'Main', basePrice: 0, restaurantId: myRestaurants[0].id })}
              className="bg-primary hover:bg-primaryHover px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-bold"
            >
              <Plus size={16} /> Add Item
            </button>
          </div>
          <div className="space-y-2">
            {menuItems.map(item => (
              <div key={item.id} className="bg-surface border border-border p-4 rounded-lg flex items-center justify-between group">
                <div className="flex items-center gap-4">
                  <img src={item.image} alt="" className="w-12 h-12 rounded bg-zinc-800 object-cover" />
                  <div>
                    <h4 className="font-bold">{item.name}</h4>
                    <p className="text-sm text-textMuted">${item.basePrice}</p>
                    <span className="text-xs text-textMuted">{myRestaurants.find(r => r.id === item.restaurantId)?.name}</span>
                  </div>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => setEditingItem(item)} className="p-2 hover:bg-zinc-700 rounded"><Edit2 size={16} /></button>
                  <button onClick={() => handleDeleteItem(item.id)} className="p-2 hover:bg-red-900/50 text-red-500 rounded"><Trash2 size={16} /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Edit Item Modal */}
      <Modal 
        isOpen={!!editingItem} 
        onClose={() => setEditingItem(null)} 
        title={editingItem?.id ? "Edit Item" : "New Item"}
      >
        <div className="space-y-4">
           {/* If admin manages multiple restaurants, let them choose */}
           {myRestaurants.length > 1 && (
             <div>
               <label className="block text-sm mb-1">Restaurant</label>
               <select 
                 className="w-full bg-background border border-border rounded p-2"
                 value={editingItem?.restaurantId || ''}
                 onChange={e => setEditingItem({ ...editingItem, restaurantId: e.target.value })}
               >
                 {myRestaurants.map(r => (
                   <option key={r.id} value={r.id}>{r.name}</option>
                 ))}
               </select>
             </div>
           )}

          <div>
            <label className="block text-sm mb-1">Name</label>
            <input 
              className="w-full bg-background border border-border rounded p-2"
              value={editingItem?.name || ''} 
              onChange={e => setEditingItem({ ...editingItem, name: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">Description</label>
            <textarea 
              className="w-full bg-background border border-border rounded p-2"
              value={editingItem?.description || ''} 
              onChange={e => setEditingItem({ ...editingItem, description: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div>
              <label className="block text-sm mb-1">Price ($)</label>
              <input 
                type="number"
                className="w-full bg-background border border-border rounded p-2"
                value={editingItem?.basePrice || 0} 
                onChange={e => setEditingItem({ ...editingItem, basePrice: parseFloat(e.target.value) })}
              />
            </div>
             <div>
              <label className="block text-sm mb-1">Category</label>
              <input 
                className="w-full bg-background border border-border rounded p-2"
                value={editingItem?.category || ''} 
                onChange={e => setEditingItem({ ...editingItem, category: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm mb-1">Image URL</label>
            <input 
              className="w-full bg-background border border-border rounded p-2"
              value={editingItem?.image || ''} 
              onChange={e => setEditingItem({ ...editingItem, image: e.target.value })}
              placeholder="https://..."
            />
          </div>
          <button onClick={handleSaveItem} className="w-full bg-primary hover:bg-primaryHover py-2 rounded font-bold">Save Item</button>
        </div>
      </Modal>
    </div>
  );
};