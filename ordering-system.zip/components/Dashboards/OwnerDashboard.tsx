import React, { useState, useEffect } from 'react';
import { User, UserRole, Restaurant, Order } from '../../types';
import { db } from '../../services/mockDb';
import { Modal } from '../Popups';
import { Users, Trash2, Shield, ShieldOff, ShoppingBag, Plus, ChefHat, Edit2 } from 'lucide-react';

export const OwnerDashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [view, setView] = useState<'users' | 'restaurants' | 'orders'>('restaurants');

  // Restaurant Editing
  const [editingRestaurant, setEditingRestaurant] = useState<Partial<Restaurant> | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setUsers(db.getUsers());
    setRestaurants(db.getRestaurants());
    setAllOrders(db.getOrders());
  };

  // --- User Logic ---
  const toggleAdmin = (userId: string, currentRole: UserRole) => {
    if (currentRole === UserRole.OWNER) return;
    const newRole = currentRole === UserRole.ADMIN ? UserRole.USER : UserRole.ADMIN;
    const updatedUsers = users.map(u => u.id === userId ? { ...u, role: newRole } : u);
    db.saveUsers(updatedUsers);
    setUsers(updatedUsers);
  };

  const removeUser = (userId: string, role: UserRole) => {
    if (role === UserRole.OWNER) return;
    if (window.confirm("Are you sure you want to remove this user?")) {
      const updatedUsers = users.filter(u => u.id !== userId);
      db.saveUsers(updatedUsers);
      setUsers(updatedUsers);
    }
  };

  // --- Restaurant Logic ---
  const handleSaveRestaurant = () => {
    if (!editingRestaurant?.name || !editingRestaurant?.deliveryFee) return;

    let newRestaurants = [...restaurants];
    if (editingRestaurant.id) {
      newRestaurants = newRestaurants.map(r => r.id === editingRestaurant.id ? { ...r, ...editingRestaurant } as Restaurant : r);
    } else {
      const newRest: Restaurant = {
        ...editingRestaurant,
        id: `r-${Date.now()}`,
        rating: 5.0,
        adminIds: editingRestaurant.adminIds || [],
        image: editingRestaurant.image || 'https://picsum.photos/400/300'
      } as Restaurant;
      newRestaurants.push(newRest);
    }
    db.saveRestaurants(newRestaurants);
    setRestaurants(newRestaurants);
    setEditingRestaurant(null);
  };

  const deleteRestaurant = (id: string) => {
    if (window.confirm("Delete this restaurant? This will hide it from users.")) {
      const newRestaurants = restaurants.filter(r => r.id !== id);
      db.saveRestaurants(newRestaurants);
      setRestaurants(newRestaurants);
    }
  };

  const toggleRestAdmin = (restId: string, adminId: string) => {
    // We are editing 'editingRestaurant' state if open, otherwise direct update not implemented in this UI flow
    // For simplicity, we only toggle inside the modal
    if (editingRestaurant) {
      const currentAdmins = editingRestaurant.adminIds || [];
      const newAdmins = currentAdmins.includes(adminId) 
        ? currentAdmins.filter(id => id !== adminId)
        : [...currentAdmins, adminId];
      setEditingRestaurant({ ...editingRestaurant, adminIds: newAdmins });
    }
  };

  const calculateGlobalRevenue = () => {
    return allOrders
      .filter(o => o.status !== 'CANCELLED')
      .reduce((acc, curr) => acc + curr.total, 0);
  };

  const getAdminNames = (adminIds: string[]) => {
    return users
      .filter(u => adminIds.includes(u.id))
      .map(u => u.name)
      .join(', ');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h1 className="text-2xl font-bold">Owner Dashboard</h1>
        <div className="flex bg-surface p-1 rounded-lg border border-border">
           <button 
            onClick={() => setView('restaurants')} 
            className={`px-4 py-2 rounded-md text-sm font-bold transition-colors flex items-center gap-2 ${view === 'restaurants' ? 'bg-primary text-white' : 'text-textMuted hover:text-white'}`}
          >
            <ChefHat size={16} /> Restaurants
          </button>
          <button 
            onClick={() => setView('users')} 
            className={`px-4 py-2 rounded-md text-sm font-bold transition-colors flex items-center gap-2 ${view === 'users' ? 'bg-primary text-white' : 'text-textMuted hover:text-white'}`}
          >
            <Users size={16} /> Users
          </button>
          <button 
            onClick={() => setView('orders')} 
            className={`px-4 py-2 rounded-md text-sm font-bold transition-colors flex items-center gap-2 ${view === 'orders' ? 'bg-primary text-white' : 'text-textMuted hover:text-white'}`}
          >
            <ShoppingBag size={16} /> All Orders
          </button>
        </div>
      </div>

      {/* Global Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-surface p-4 rounded-xl border border-border">
           <p className="text-textMuted text-xs uppercase font-bold">Total Revenue</p>
           <p className="text-2xl font-bold text-green-500">${calculateGlobalRevenue().toFixed(2)}</p>
        </div>
        <div className="bg-surface p-4 rounded-xl border border-border">
           <p className="text-textMuted text-xs uppercase font-bold">Restaurants</p>
           <p className="text-2xl font-bold">{restaurants.length}</p>
        </div>
        <div className="bg-surface p-4 rounded-xl border border-border">
           <p className="text-textMuted text-xs uppercase font-bold">Total Users</p>
           <p className="text-2xl font-bold">{users.length}</p>
        </div>
        <div className="bg-surface p-4 rounded-xl border border-border">
           <p className="text-textMuted text-xs uppercase font-bold">Total Orders</p>
           <p className="text-2xl font-bold">{allOrders.length}</p>
        </div>
      </div>

      {view === 'users' && (
        <div className="bg-surface border border-border rounded-xl overflow-hidden animate-in fade-in">
          <div className="p-4 border-b border-border flex items-center gap-2">
            <Users className="text-primary" />
            <h3 className="font-bold">User Management</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-background text-textMuted text-sm">
                <tr>
                  <th className="p-4">Name</th>
                  <th className="p-4">Email</th>
                  <th className="p-4">Role</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id} className="border-b border-border last:border-0 hover:bg-zinc-800/50 transition-colors">
                    <td className="p-4 font-medium">{user.name}</td>
                    <td className="p-4 text-textMuted">{user.email}</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${
                        user.role === 'OWNER' ? 'bg-yellow-500/20 text-yellow-500' :
                        user.role === 'ADMIN' ? 'bg-blue-500/20 text-blue-500' :
                        'bg-zinc-700 text-textMuted'
                      }`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex justify-end gap-2">
                        {user.role !== UserRole.OWNER && (
                          <>
                            <button 
                              onClick={() => toggleAdmin(user.id, user.role)}
                              className="p-2 rounded bg-zinc-800 hover:bg-zinc-700 text-sm"
                              title={user.role === 'ADMIN' ? 'Remove Admin' : 'Make Admin'}
                            >
                              {user.role === 'ADMIN' ? <ShieldOff size={16} className="text-red-400" /> : <Shield size={16} className="text-blue-400" />}
                            </button>
                            <button 
                              onClick={() => removeUser(user.id, user.role)}
                              className="p-2 rounded bg-red-900/20 hover:bg-red-900/40 text-red-500"
                              title="Remove User"
                            >
                              <Trash2 size={16} />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {view === 'restaurants' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="flex justify-end">
            <button 
              onClick={() => setEditingRestaurant({ deliveryFee: 0, adminIds: [] })}
              className="bg-primary hover:bg-primaryHover px-4 py-2 rounded-lg font-bold flex items-center gap-2"
            >
              <Plus size={18} /> Add Restaurant
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {restaurants.map(rest => (
              <div key={rest.id} className="bg-surface border border-border p-4 rounded-xl flex gap-4 group">
                <img src={rest.image} alt="" className="w-24 h-24 object-cover rounded-lg bg-zinc-800" />
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h3 className="font-bold text-lg">{rest.name}</h3>
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                       <button onClick={() => setEditingRestaurant(rest)} className="p-1 hover:bg-zinc-700 rounded"><Edit2 size={16} /></button>
                       <button onClick={() => deleteRestaurant(rest.id)} className="p-1 hover:bg-red-900/50 text-red-500 rounded"><Trash2 size={16} /></button>
                    </div>
                  </div>
                  <p className="text-sm text-textMuted mt-1">Delivery: ${rest.deliveryFee}</p>
                  <div className="mt-2 text-xs">
                    <span className="text-textMuted">Admins: </span>
                    <span className="text-white">{getAdminNames(rest.adminIds) || 'None'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {view === 'orders' && (
        <div className="bg-surface border border-border rounded-xl overflow-hidden animate-in fade-in">
           <div className="p-4 border-b border-border">
             <h3 className="font-bold">System-wide Order History</h3>
           </div>
           <div className="max-h-[600px] overflow-y-auto">
             {allOrders.length === 0 && <p className="p-8 text-center text-textMuted">No orders found.</p>}
             {allOrders.slice().reverse().map(order => (
               <div key={order.id} className="p-4 border-b border-border last:border-0 hover:bg-zinc-800/20">
                 <div className="flex justify-between mb-2">
                   <span className="font-bold">Order #{order.id.slice(-4)}</span>
                   <span className={`text-xs px-2 py-0.5 rounded font-bold ${
                      order.status === 'PENDING' ? 'bg-yellow-500/20 text-yellow-500' : 
                      order.status === 'PREPARING' ? 'bg-blue-500/20 text-blue-500' :
                      order.status === 'DELIVERED' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'
                   }`}>{order.status}</span>
                 </div>
                 <div className="flex justify-between text-sm text-textMuted">
                   <span>{order.userName}</span>
                   <span>${order.total.toFixed(2)}</span>
                 </div>
                 <p className="text-xs text-textMuted mt-1">{new Date(order.createdAt).toLocaleString()}</p>
               </div>
             ))}
           </div>
        </div>
      )}

      {/* Restaurant Modal */}
      <Modal
        isOpen={!!editingRestaurant}
        onClose={() => setEditingRestaurant(null)}
        title={editingRestaurant?.id ? "Edit Restaurant" : "New Restaurant"}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm mb-1">Name</label>
            <input 
              className="w-full bg-background border border-border rounded p-2"
              value={editingRestaurant?.name || ''} 
              onChange={e => setEditingRestaurant({ ...editingRestaurant, name: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">Image URL</label>
            <input 
              className="w-full bg-background border border-border rounded p-2"
              value={editingRestaurant?.image || ''} 
              onChange={e => setEditingRestaurant({ ...editingRestaurant, image: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">Delivery Fee ($)</label>
            <input 
              type="number"
              className="w-full bg-background border border-border rounded p-2"
              value={editingRestaurant?.deliveryFee || 0} 
              onChange={e => setEditingRestaurant({ ...editingRestaurant, deliveryFee: parseFloat(e.target.value) })}
            />
          </div>
          
          <div className="pt-2 border-t border-border">
            <label className="block text-sm font-bold mb-2">Assign Admins</label>
            <div className="space-y-2 max-h-40 overflow-y-auto bg-background p-2 rounded border border-border">
              {users.filter(u => u.role === UserRole.ADMIN).length === 0 && <p className="text-xs text-textMuted">No admins found. Go to 'Users' tab to promote users.</p>}
              
              {users.filter(u => u.role === UserRole.ADMIN).map(admin => (
                <div key={admin.id} className="flex items-center gap-2">
                  <input 
                    type="checkbox"
                    id={`admin-${admin.id}`}
                    checked={editingRestaurant?.adminIds?.includes(admin.id) || false}
                    onChange={() => toggleRestAdmin(editingRestaurant?.id || 'new', admin.id)}
                    className="accent-primary"
                  />
                  <label htmlFor={`admin-${admin.id}`} className="text-sm cursor-pointer">{admin.name}</label>
                </div>
              ))}
            </div>
          </div>

          <button onClick={handleSaveRestaurant} className="w-full bg-primary hover:bg-primaryHover py-2 rounded font-bold mt-4">Save Restaurant</button>
        </div>
      </Modal>
    </div>
  );
};