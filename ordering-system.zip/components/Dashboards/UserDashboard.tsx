import React, { useState, useEffect } from 'react';
import { User, Restaurant, MenuItem, CartItem, Order, Size } from '../../types';
import { db } from '../../services/mockDb';
import { Modal, ConfirmModal } from '../Popups';
import { ShoppingBag, Star, Plus, Minus, ChefHat, Clock } from 'lucide-react';

interface UserDashboardProps {
  currentUser: User;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({ currentUser }) => {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [activeOrders, setActiveOrders] = useState<Order[]>([]);
  
  // Item Modal State
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [size, setSize] = useState<Size>('M');
  const [note, setNote] = useState('');
  const [quantity, setQuantity] = useState(1);

  // Cart Logic
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [pendingCartItem, setPendingCartItem] = useState<CartItem | null>(null);
  const [isConflictModalOpen, setIsConflictModalOpen] = useState(false);

  useEffect(() => {
    setRestaurants(db.getRestaurants());
    setMenuItems(db.getMenu());
    const orders = db.getOrders().filter(o => o.userId === currentUser.id);
    setActiveOrders(orders);
  }, [currentUser.id]);

  const initiateAddToCart = () => {
    if (!selectedItem || !selectedRestaurant) return;

    let priceMultiplier = 1;
    if (size === 'S') priceMultiplier = 0.8;
    if (size === 'L') priceMultiplier = 1.2;

    const newItem: CartItem = {
      itemId: selectedItem.id,
      name: selectedItem.name,
      size,
      price: selectedItem.basePrice * priceMultiplier,
      quantity,
      note,
      restaurantId: selectedRestaurant.id
    };

    // Check for restaurant conflict
    if (cart.length > 0 && cart[0].restaurantId !== selectedRestaurant.id) {
      setPendingCartItem(newItem);
      setIsConflictModalOpen(true);
    } else {
      addToCart(newItem);
    }
  };

  const addToCart = (item: CartItem) => {
    setCart(prev => [...prev, item]);
    resetSelection();
  };

  const confirmNewBasket = () => {
    if (pendingCartItem) {
      setCart([pendingCartItem]);
      setPendingCartItem(null);
      resetSelection();
    }
  };

  const resetSelection = () => {
    setSelectedItem(null);
    setNote('');
    setQuantity(1);
    setSize('M');
  };

  const placeOrder = () => {
    if (cart.length === 0 || !selectedRestaurant) return;
    
    const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0) + selectedRestaurant.deliveryFee;
    
    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      items: cart,
      total,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      deliveryFee: selectedRestaurant.deliveryFee
    };

    const updatedOrders = [...db.getOrders(), newOrder];
    db.saveOrders(updatedOrders);
    setActiveOrders(updatedOrders.filter(o => o.userId === currentUser.id));
    setCart([]);
    setIsCartOpen(false);
    setSelectedRestaurant(null); 
  };

  const removeFromCart = (index: number) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
    if (newCart.length === 0) setIsCartOpen(false);
  };

  if (selectedRestaurant) {
    const restaurantMenu = menuItems.filter(m => m.restaurantId === selectedRestaurant.id);

    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => setSelectedRestaurant(null)}
            className="text-sm text-primary hover:underline"
          >
            ← Back to Restaurants
          </button>
          <h2 className="text-2xl font-bold">{selectedRestaurant.name}</h2>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {restaurantMenu.map(item => (
            <div 
              key={item.id}
              onClick={() => setSelectedItem(item)}
              className="bg-surface border border-border rounded-xl overflow-hidden hover:border-primary transition-colors cursor-pointer group"
            >
              <div className="h-48 overflow-hidden">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-lg">{item.name}</h3>
                  <span className="font-bold text-primary">${item.basePrice}</span>
                </div>
                <p className="text-sm text-textMuted line-clamp-2">{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Floating Cart Button */}
        {cart.length > 0 && (
          <div className="fixed bottom-8 right-8 z-40">
            <button
              onClick={() => setIsCartOpen(true)}
              className="bg-primary hover:bg-primaryHover text-white px-6 py-4 rounded-full shadow-2xl flex items-center gap-3 font-bold animate-bounce"
            >
              <ShoppingBag />
              <span>{cart.length} items</span>
              <span className="bg-white/20 px-2 py-0.5 rounded text-sm">
                ${cart.reduce((a, b) => a + (b.price * b.quantity), 0).toFixed(2)}
              </span>
            </button>
          </div>
        )}

        {/* Item Customization Modal */}
        <Modal 
          isOpen={!!selectedItem} 
          onClose={() => setSelectedItem(null)} 
          title="Customize Item"
        >
          {selectedItem && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">{selectedItem.name}</h3>
                <span className="text-primary font-bold text-xl">${selectedItem.basePrice}</span>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-textMuted mb-2">Size</label>
                <div className="flex gap-2">
                  {(['S', 'M', 'L'] as Size[]).map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={`flex-1 py-2 rounded-lg border ${
                        size === s 
                          ? 'border-primary bg-primary/10 text-primary' 
                          : 'border-border hover:bg-zinc-800'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-textMuted mb-2">Special Instructions</label>
                <textarea
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  placeholder="E.g., No onions, extra sauce..."
                  className="w-full bg-background border border-border rounded-lg p-3 h-24 resize-none focus:outline-none focus:border-primary"
                />
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div className="flex items-center gap-4 bg-background rounded-lg p-1 border border-border">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 hover:bg-zinc-800 rounded text-textMuted hover:text-white"
                  >
                    <Minus size={16} />
                  </button>
                  <span className="w-8 text-center font-bold">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2 hover:bg-zinc-800 rounded text-textMuted hover:text-white"
                  >
                    <Plus size={16} />
                  </button>
                </div>
                <button
                  onClick={initiateAddToCart}
                  className="bg-primary hover:bg-primaryHover px-6 py-2 rounded-lg font-bold"
                >
                  Add to Order - ${(selectedItem.basePrice * (size === 'S' ? 0.8 : size === 'L' ? 1.2 : 1) * quantity).toFixed(2)}
                </button>
              </div>
            </div>
          )}
        </Modal>

        {/* Conflict Modal */}
        <ConfirmModal 
          isOpen={isConflictModalOpen}
          onClose={() => setIsConflictModalOpen(false)}
          onConfirm={confirmNewBasket}
          title="Start New Basket?"
          message="Adding items from a different restaurant will clear your current basket. Do you want to continue?"
        />

        {/* Cart Review Modal */}
        <Modal 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          title={`Your Order from ${selectedRestaurant.name}`}
        >
          <div className="space-y-4">
            {cart.map((item, idx) => (
              <div key={idx} className="flex justify-between items-start border-b border-border pb-4 last:border-0">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{item.quantity}x</span>
                    <span className="font-medium">{item.name}</span>
                    <span className="text-xs bg-zinc-800 px-1.5 rounded text-textMuted">{item.size}</span>
                  </div>
                  {item.note && <p className="text-xs text-textMuted mt-1">Note: {item.note}</p>}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className="font-bold">${(item.price * item.quantity).toFixed(2)}</span>
                  <button 
                    onClick={() => removeFromCart(idx)}
                    className="text-xs text-red-500 hover:text-red-400"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
            
            <div className="pt-4 border-t border-border space-y-2">
              <div className="flex justify-between text-textMuted">
                <span>Subtotal</span>
                <span>${cart.reduce((a, b) => a + (b.price * b.quantity), 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-textMuted">
                <span>Delivery Fee</span>
                <span>${selectedRestaurant.deliveryFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-xl font-bold pt-2">
                <span>Total</span>
                <span className="text-primary">
                  ${(cart.reduce((a, b) => a + (b.price * b.quantity), 0) + selectedRestaurant.deliveryFee).toFixed(2)}
                </span>
              </div>
            </div>

            <button
              onClick={placeOrder}
              className="w-full bg-primary hover:bg-primaryHover py-3 rounded-lg font-bold mt-4"
            >
              Checkout
            </button>
          </div>
        </Modal>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Active Orders Section */}
      {activeOrders.length > 0 && (
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Clock className="text-primary" /> Active Orders
          </h2>
          <div className="grid gap-4 md:grid-cols-2">
            {activeOrders.map(order => (
              <div key={order.id} className="bg-surface border border-border p-4 rounded-xl flex justify-between items-center">
                <div>
                  <p className="font-bold text-lg">Order #{order.id.slice(-4)}</p>
                  <p className="text-textMuted text-sm">{order.items.length} Items • ${order.total.toFixed(2)}</p>
                  <p className="text-xs text-textMuted mt-1">{new Date(order.createdAt).toLocaleTimeString()}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-bold
                  ${order.status === 'PENDING' ? 'bg-yellow-500/20 text-yellow-500' : 
                    order.status === 'PREPARING' ? 'bg-blue-500/20 text-blue-500' :
                    order.status === 'DELIVERED' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'
                  }`}
                >
                  {order.status}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Restaurant List */}
      <section>
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <ChefHat className="text-primary" /> Restaurants
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {restaurants.map(rest => (
            <div 
              key={rest.id}
              onClick={() => setSelectedRestaurant(rest)}
              className="bg-surface border border-border rounded-xl overflow-hidden cursor-pointer hover:border-primary transition-all group"
            >
              <div className="relative h-48">
                <img src={rest.image} alt={rest.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg flex items-center gap-1 text-sm font-bold">
                  <Star size={14} className="text-yellow-400 fill-yellow-400" />
                  {rest.rating}
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg mb-1">{rest.name}</h3>
                <p className="text-sm text-textMuted">Delivery: ${rest.deliveryFee.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};