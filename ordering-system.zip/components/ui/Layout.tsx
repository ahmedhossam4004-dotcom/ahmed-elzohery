import React from 'react';
import { LogOut, User as UserIcon, Shield, Crown } from 'lucide-react';
import { User, UserRole } from '../../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  return (
    <div className="min-h-screen bg-background text-textMain flex flex-col">
      {/* Navbar */}
      <nav className="border-b border-border bg-surface sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center font-bold text-white">
              OS
            </div>
            <span className="font-bold text-xl tracking-tight">Ordering<span className="text-primary">System</span></span>
          </div>

          {user && (
            <div className="flex items-center gap-4">
              <div className="hidden md:flex flex-col items-end">
                <span className="text-sm font-medium">{user.name}</span>
                <span className="text-xs text-textMuted flex items-center gap-1">
                  {user.role === UserRole.OWNER && <Crown size={12} className="text-yellow-500" />}
                  {user.role === UserRole.ADMIN && <Shield size={12} className="text-blue-500" />}
                  {user.role}
                </span>
              </div>
              <button
                onClick={onLogout}
                className="p-2 hover:bg-zinc-800 rounded-full transition-colors"
                title="Sign Out"
              >
                <LogOut size={20} className="text-textMuted hover:text-white" />
              </button>
            </div>
          )}
        </div>
      </nav>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <footer className="border-t border-border bg-surface py-6 text-center text-textMuted text-sm">
        <p>&copy; {new Date().getFullYear()} Ordering System. All rights reserved.</p>
      </footer>
    </div>
  );
};